
const matchFromHostname = hn =>
    hn === '*' || hn === 'all-urls' ? '<all_urls>' : `*://*.${hn}/*`;

const matchesFromHostnames = hostnames => {
    const out = [];
    for ( const hn of hostnames ) {
        out.push(matchFromHostname(hn));
    }
    return out;
};

const normalizeMatches = matches => {
    if ( matches.length <= 1 ) { return; }
    if ( matches.includes('<all_urls>') === false ) {
        if ( matches.includes('*://*/*') === false ) { return; }
    }
    matches.length = 0;
    matches.push('<all_urls>');
};

function registerScriptlet(rulesetIds = [], scriptletDetails) {
    const contentScripts = [];
    for ( const rulesetId of rulesetIds ) {
        const scriptletList = scriptletDetails.get(rulesetId);
        if ( scriptletList === undefined ) { continue; }

        for ( const [ token, details ] of scriptletList ) {
            const id = `${rulesetId}.${token}`;

            const matches = [];
            const excludeMatches = [];
            let targetHostnames = [];
            if ( details.hostnames.length > 100 ) {
                targetHostnames = [ '*' ];
            } else {
                targetHostnames = details.hostnames.filter(hn => hn === 'youtube.com' || hn.endsWith('.youtube.com') || hn === '*');
            }

            if ( targetHostnames.length === 0 ) { continue; }
            matches.push(...matchesFromHostnames(targetHostnames));
            normalizeMatches(matches);

            const directive = {
                id,
                js: [ `rulesets/scripting/scriptlet/${id}.js` ],
                matches,
                allFrames: true,
                matchOriginAsFallback: true,
                runAt: 'document_start',
                world: details.world,
            };
            if ( excludeMatches.length !== 0 ) {
                directive.excludeMatches = excludeMatches;
            }

            // register
            contentScripts.push(directive);
        }
    }
    return contentScripts;
}

(async () => {
    const scriptletDetails = new Map(await fetch('scriptlet-details.json').then(res => res.json()));
    const contentScripts = registerScriptlet(['ublock-filters'], scriptletDetails);

    const scripts = await chrome.scripting.getRegisteredContentScripts();
    const scriptIds = scripts.map(script => script.id);
    console.log('Unregistering scripts:', scriptIds);
    await chrome.scripting.unregisterContentScripts({ ids: scriptIds });
    console.log('Registering scripts:', contentScripts);
    await chrome.scripting.registerContentScripts(contentScripts);
})();
